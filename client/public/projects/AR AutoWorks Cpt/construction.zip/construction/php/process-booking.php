<?php
include 'db.php';
include '../emails/send-email.php';

header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);

$name = $data['name'];
$contact = $data['contact'];
$carModel = $data['carModel'];
$date = $data['date'];
$time = $data['time'];

$sql = "INSERT INTO bookings (name, contact, car_model, date, time) VALUES ('$name', '$contact', '$carModel', '$date', '$time')";

if ($conn->query($sql) === TRUE) {
    $ownerEmail = 'hermanus138@gmail.com';
    $userEmail = $contact;

    $subject = "New Booking Request";
    $body = "You have a new booking request from $name for $carModel on $date at $time.";

    sendEmail($ownerEmail, $subject, $body);
    sendEmail($userEmail, $subject, "Your booking request has been submitted.");

    $response = ['message' => 'Booking request submitted successfully!'];
} else {
    $response = ['message' => 'Error: ' . $conn->error];
}

$conn->close();

echo json_encode($response);
?>

