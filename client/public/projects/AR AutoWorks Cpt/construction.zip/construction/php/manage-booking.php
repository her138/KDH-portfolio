<?php
include 'db.php';

$id = $_POST['id'];
$status = $_POST['status'];

$sql = "UPDATE bookings SET status = '$status' WHERE id = $id";

if ($conn->query($sql) === TRUE) {
    echo "Booking status updated successfully!";
} else {
    echo "Error updating record: " . $conn->error;
}

$conn->close();
?>
