const express = require('express');
const bodyParser = require('body-parser');
const nodemailer = require('nodemailer');
const mongoose = require('mongoose');
const app = express();
const port = process.env.PORT || 3000;

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Connect to MongoDB
mongoose.connect('mongodb://localhost/ar-autoworks', {
    useNewUrlParser: true,
    useUnifiedTopology: true
});

// Define a Booking Schema
const bookingSchema = new mongoose.Schema({
    name: String,
    contact: String,
    carModel: String,
    date: Date,
    time: String,
    status: { type: String, default: 'Pending' }
});

const Booking = mongoose.model('Booking', bookingSchema);

// Setup Nodemailer Transporter
const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: 'your_email@gmail.com',  // Replace with your email
        pass: 'your_email_password'    // Replace with your email password
    }
});

// Endpoint to Handle Booking Requests
app.post('/api/bookings', async (req, res) => {
    const { name, contact, carModel, date, time } = req.body;

    try {
        const newBooking = new Booking({ name, contact, carModel, date, time });
        await newBooking.save();

        // Notify the owner
        const mailOptions = {
            from: 'your_email@gmail.com',
            to: 'hermanus138@gmail.com',
            subject: 'New Booking Request',
            text: `New booking request:\nName: ${name}\nContact: ${contact}\nCar Model: ${carModel}\nDate: ${date}\nTime: ${time}\n\nClick here to accept or decline: http://yourdomain.com/api/bookings/${newBooking._id}`
        };

        transporter.sendMail(mailOptions, (error, info) => {
            if (error) {
                return res.status(500).json({ message: 'Failed to send email.' });
            }
            res.json({ message: 'Booking request sent successfully.' });
        });
    } catch (error) {
        res.status(500).json({ message: 'Failed to save booking.' });
    }
});

// Endpoint to Accept or Decline Booking
app.get('/api/bookings/:id/:status', async (req, res) => {
    const { id, status } = req.params;

    try {
        const booking = await Booking.findById(id);
        if (!booking) return res.status(404).json({ message: 'Booking not found.' });

        booking.status = status;
        await booking.save();

        // Notify the user
        const mailOptions = {
            from: 'your_email@gmail.com',
            to: booking.contact,
            subject: 'Booking Status Update',
            text: `Your booking on ${booking.date} at ${booking.time} has been ${status}.`
        };

        transporter.sendMail(mailOptions, (error, info) => {
            if (error) {
                return res.status(500).json({ message: 'Failed to send email.' });
            }
            res.json({ message: `Booking ${status} successfully.` });
        });
    } catch (error) {
        res.status(500).json({ message: 'Failed to update booking.' });
    }
});

app.listen(port, () => {
    console.log(`Server running on port ${port}`);
});
require('dotenv').config();

const Transport = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS
    }
});

mongoose.connect(process.env.MONGO_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true
});
